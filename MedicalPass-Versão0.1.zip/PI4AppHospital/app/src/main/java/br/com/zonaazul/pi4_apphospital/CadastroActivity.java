package br.com.zonaazul.pi4_apphospital;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class CadastroActivity extends AppCompatActivity {

    private FirebaseAuth auth;

    private EditText editEmail;
    private EditText editPassword;
    private EditText editNome;
    private EditText editRG;

    private TextInputLayout tilNome;
    private TextInputLayout tilRG;
    private TextInputLayout tilEmail;
    private TextInputLayout tilSenha;

    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        editEmail = findViewById(R.id.cadEmail);
        editPassword = findViewById(R.id.cadPassword);
        editNome = findViewById(R.id.cadNome);
        editRG = findViewById(R.id.cadRG);

        tilNome = findViewById(R.id.tilNome);
        tilRG = findViewById(R.id.tilRG);
        tilEmail = findViewById(R.id.tilEmail);
        tilSenha = findViewById(R.id.tilSenha);

        Button btnRegister =  findViewById(R.id.btncadastro);
        Button btnVoltar = findViewById(R.id.btnvoltar);
        View view = findViewById(R.id.activity_cadastro);

        auth = FirebaseAuth.getInstance();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = editEmail.getText().toString().trim();
                String password = editPassword.getText().toString().trim();
                String nome = editNome.getText().toString().trim();
                String RG = editRG.getText().toString().trim();

                if(nome.isEmpty()){
                    tilNome.setError("É necessário adicionar o seu nome");
                }
                if(RG.isEmpty()){
                    tilRG.setError("É necessário adicionar o seu RG");
                }
                if(email.isEmpty()){
                    tilEmail.setError("É necessário adicionar o seu email");
                }
                if(password.isEmpty()){
                    tilSenha.setError("É necessário adicionar a sua senha");
                }
                else{
                    registerUser(email, password);
                }
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent voltar = new Intent(CadastroActivity.this, LoginActivity.class);
                startActivity(voltar);
            }
        });
    }

    private void registerUser(String editEmail, String editPassword){
        auth.createUserWithEmailAndPassword(editEmail, editPassword).addOnCompleteListener(CadastroActivity.this, task -> {
            if(task.isSuccessful()){
                
                salvarDadosUsuario();
                
                Toast.makeText(CadastroActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_LONG).show();

                startActivity(new Intent(CadastroActivity.this, LoginActivity.class));
                finish();
            }
            else{
                try {
                    throw Objects.requireNonNull(task.getException());
                } catch (FirebaseAuthWeakPasswordException e) {
                    tilSenha.setError("Digite uma senha com no mínimo 6 caracteres");
                } catch (FirebaseAuthUserCollisionException e) {
                    tilEmail.setError("Este e-mail já foi cadastrado");
                } catch (FirebaseAuthInvalidCredentialsException e) {
                    tilEmail.setError("E-mail inválido");
                } catch (Exception e) {
                    Toast.makeText(CadastroActivity.this, "Erro ao realizar cadastro", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void salvarDadosUsuario() {
        String email = editEmail.getText().toString().trim();
        String nome = editNome.getText().toString().trim();
        String RG = editRG.getText().toString().trim();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> users = new HashMap<>();
        users.put("Nome", nome);
        users.put("Email", email);
        users.put("RG", RG);

        userID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentReference = db.collection("Users").document(userID);
        documentReference.set(users).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.v("db", "Dados inseridos com sucesso");
            }
        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.v("db", "Erro ao inserir os dados");
                    }
        });
    }
}