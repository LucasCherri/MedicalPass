package br.com.zonaazul.pi4_apphospital;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    View view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText Loginemail = findViewById(R.id.loginEmail);
        EditText Loginpassword = findViewById(R.id.loginPassword);
        Button Btnlogar =  findViewById(R.id.btnLogar);
        TextView Btntelacadstro = findViewById(R.id.btnTelaCadastro);
        view = findViewById(R.id.activity_login);

        auth = FirebaseAuth.getInstance();

        Btnlogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = Loginemail.getText().toString().trim();
                String password = Loginpassword.getText().toString().trim();

                loginUser(email, password);
            }
        });

        Btntelacadstro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(LoginActivity.this, CadastroActivity.class));
               finish();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null){
            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
            finish();
        }
    }

    private void loginUser(String Loginemail, String Loginpassword) {
        auth.signInWithEmailAndPassword(Loginemail, Loginpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    setProgressBarVisibility(true);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                            finish();
                        }
                    },3000);
                }
                else{
                    try {
                        throw task.getException();
                    } catch (Exception e) {
                        Snackbar.make(view, "Usuário ou senha incorretos", Snackbar.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
}